# RN-Tutorial-Main
<p>
  This repo contains all the course files for the React Native Tutorial playlist on The Programming with Mash Channel
https://www.youtube.com/playlist?list=PL8kfZyp--gEXs4YsSLtB3KqDtdOFHMjWZ
</p>
<h2>Using the course files</h2>
<p>
Each session in the series has its own branch, so you'll need to select that branch to see the codes for that session. For example to see the codes for session 5, you would select the RN-Tutorial-05 branch.
</p>
<h2>Installing dependencies</h2>
<p>
If you download or clone the repo, you will need to run "npm install" in the project directory to install any project dependencies first. Without doing this, the code may not work as expected.
</p>
